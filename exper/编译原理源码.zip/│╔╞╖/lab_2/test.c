int a;
float a;
int test1(int a,int b)
{	return 1;
}
int test1()
{	return 0;
}
int test2(int a,int a){
	return 0;
}
int main(){	
	int i,j;
	float i,i=1;
	char k;
	test1(1);
	test1('a',1);
	test1(1,2,3);

	m;
	
	test1;
	
	3=2;
	
	test213123();

	j();
	
	k=k+1;
	
	!k;
	
	k<2;
	
	-k;
	
	
	return 1.0;
}