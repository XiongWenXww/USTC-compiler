**问题2-1**：

1. **`-nostdinc`选项的用处是什么？**

2. **请列出 EduCoder 平台上 `gcc` C程序默认的头文件查找路径**

3. **如何在使用了`-nostdinc`选项的同时使得上述命令编译通过? 请进一步说明通过的原因（不能修改源文件）。**

   

   1. -nostdinc :不搜索默认路径头文件。

   2. 使用`gcc -v -x c -E /dev/null`得到头文件默认查找路径：

   ```
   #include "..." search starts here:
   #include <...> search starts here:
    /usr/lib/gcc/x86_64-linux-gnu/5/include
    /usr/local/include
    /usr/lib/gcc/x86_64-linux-gnu/5/include-fixed
    /usr/include/x86_64-linux-gnu
    /usr/include
   ```

   3. 用-I选项指定路径：`gcc -c sample-io.c -I /data/workspace/myshixun/`

**问题2-2**：

1. **`-nostdlib`选项的用处是什么？**
2. **请列出 EduCoder 平台上 `gcc` C程序默认链接的库**
3. **如何在使用了`-nostdlib`选项的同时使得上述命令编译通过？请进一步说明通过的原因（不能修改源文件）。**
   1. -nostdlib: 不使用标准库
   2. c语言标准库，libgcc.a、libgcc_s.so
   3. 

