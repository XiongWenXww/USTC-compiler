**问题1-1**：

**如果在命令行下执行  `gcc -DNEG -E sample.c -o sample.i` 生成的`sample.i` 与之前的有何区别？**

如下为执行`gcc -E sample.c -o sample.i `得到的`sample.i`

```
# 1 "sample.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 1 "<command-line>" 2
# 1 "sample.c"
int main()
{
    int a = 4;
    if (a)
        a = a + 4;
    else
        a = a * 4;
    return 0;
}

```

如下为执行`gcc -DENG -E sample.c -o sample.i `得到的`sample.i`

```
# 1 "sample.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 1 "<command-line>" 2
# 1 "sample.c"
int main()
{
    int a = -4;
    if (a)
        a = a + 4;
    else
        a = a * 4;
    return 0;
}
```

可以观察到，执行`gcc -DENG -E sample.c -o sample.i `得到的`sample.i`得到的M为-4，而执行`gcc -E sample.c -o sample.i `得到的M为4，这是因为，`gcc -DENG -E sample.c -o sample.i` 对ENG进行了定义，则在宏中将M赋值为-4。

**问题1-2** 

**请对比`sample-32.s`和`sample.s`，简要说明它们核心汇编代码的区别以及产生这些区别的原因。如：**

- **`pushq`和`pushl`**
- **`rsp`和`esp`**

32位汇编中的esp、ebp分别指栈指针寄存器、基址指针寄存器，而rsp、rbp则为64位汇编中的栈指针寄存器、基址指针寄存器。**故64位汇编中的寄存器均为rsp、esp，32位汇编中的寄存器均为esp、ebp。**

汇编语言中，后缀为l表示处理的为双字，也就是32位，后缀为q表示处理的为四字，也就是64位。

由于int在32位、64位操作系统中都占32位，

**故在64位汇编中**，对int型数据的操作如

```
movl    $4, -4(%rbp)
cmpl    $0, -4(%rbp)
addl    $4, -4(%rbp)
```

等指令的后缀均为l，而其他不对int型数据的操作的后缀则为q，如

```
pushq   %rbp
movq    %rsp, %rbp
```

**而在32位汇编中的操作的后缀都为l。**

