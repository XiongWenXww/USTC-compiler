#include "stdio.h"
#define N 1000

void sort(int* a,int len) {
    int i, j, t;
    for (i = 0; i < len; ++i) {
        for (j = 0; j < len - i - 1; ++j) {
            if (a[j] > a[j + 1]) {
                t = a[j];
                a[j] = a[j + 1];
                a[j + 1] = t;
            }
        }
    }
}

int main() {
    int n, a[N], t;

    int i;
    scanf_s("%d", &n);
    for (i = 0; i < n; ++i){
        scanf_s("%d", &a[i]);
    }
    
    sort(a, n);
    for (i = 0; i < n; ++i) {
        printf("%d ", a[i]);
    }
    return 0;
}