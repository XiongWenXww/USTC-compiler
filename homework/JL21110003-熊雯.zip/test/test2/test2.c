#include<stdio.h>

int main(){
    int a = 3;
    int b = a;
    int c = b + 4;
    return 0;
}